# zvoworld.io — Reference Wiki Links

For full details on features, mechanics, foods, mobs, biomes, and more, see the following sources:

- [EvoWorld.io Wiki](https://evoworldio.fandom.com/wiki/EvoWorld.io)
- [Structures](https://evoworldio.fandom.com/wiki/Structures)
- [Characters](https://evoworldio.fandom.com/wiki/Characters)
- [Level](https://evoworldio.fandom.com/wiki/Level)
- [Pet](https://evoworldio.fandom.com/wiki/Pet)
- ... (full list in user prompt above)

**Note:** Consult these links for specifics when developing each feature.
